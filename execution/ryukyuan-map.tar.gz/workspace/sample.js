// CSVファイルを読み込む関数getCSV()の定義
var readdata=[];
function getCSV(){
    var req = new XMLHttpRequest(); // HTTPでファイルを読み込むためのXMLHttpRrequestオブジェクトを生成
    req.open("get", "./allK5.csv", true); // アクセスするファイルを指定
    req.send(null); // HTTPリクエストの発行allK5.csv
	
    // レスポンスが返ってきたらconvertCSVtoArray()を呼ぶ	
    req.onload = function(){
	convertCSVtoArray(req.responseText); // 渡されるのは読み込んだCSVデータ
    }
}
// 読み込んだCSVデータを二次元配列に変換する関数convertCSVtoArray()の定義
function convertCSVtoArray(str){ // 読み込んだCSVデータが文字列として渡される
    // var result = []; // 最終的な二次元配列を入れるための配列
    var tmp = str.split("\n"); // 改行を区切り文字として行を要素とした配列を生成
 
    // 各行ごとにカンマで区切った文字列を要素とした二次元配列を生成
    for(var i=1;i<tmp.length;++i){
        readdata[i-1] = tmp[i].split(',');
    }
 
    // alert(readdata); // 300yen
}
window.onload=getCSV();

var map;
// // var marker;
// // var geocoder;
var marker;
var geocoder;
var marker1;
var geocoder1;
var marker2;
var geocoder2;
var marker3;
var geocoder3;
var marker4;
var geocoder4;
var marker5;
var geocoder5;
var marker6;
var geocoder6;
var marker7;
var geocoder7;
var marker8;
var geocoder8;
var marker9;
var geocoder9;
var marker10;
var geocoder10;
var marker11;
var geocoder11;
var marker12;
var geocoder12;
var marker13;
var geocoder13;
var marker14;
var geocoder14;
var marker15;
var geocoder15;
var marker16;
var geocoder16;
var marker17;
var geocoder17;
var marker18;
var geocoder18;
var marker19;
var geocoder19;
var marker20;
var geocoder20;
var marker21;
var geocoder21;
var marker22;
var geocoder22;
var marker23;
var geocoder23;
var marker24;
var geocoder24;
var marker25;
var geocoder25;
var marker26;
var geocoder26;
var marker27;
var geocoder27;
var marker28;
var geocoder28;
var marker29;
var geocoder29;
var marker30;
var geocoder30;
var marker31;
var geocoder31;
var marker32;
var geocoder32;
var marker33;
var geocoder33;
var marker34;
var geocoder34;
var marker35;
var geocoder35;
var marker36;
var geocoder36;
var marker37;
var geocoder37;
var marker38;
var geocoder38;
var marker39;
var geocoder39;
var marker40;
var geocoder40;
var marker41;
var geocoder41;
var marker42;
var geocoder42;
var marker43;
var geocoder43;
var marker44;
var geocoder44;
var marker45;
var geocoder45;
var marker46;
var geocoder46;
var marker47;
var geocoder47;
var marker48;
var geocoder48;
var marker49;
var geocoder49;
var marker50;
var geocoder50;
var marker51;
var geocoder51;
var marker52;
var geocoder52;
var marker53;
var geocoder53;
var marker54;
var geocoder54;
var marker55;
var geocoder55;
var marker56;
var geocoder56;
var marker57;
var geocoder57;
var marker58;
var geocoder58;
var marker59;
var geocoder59;
var marker60;
var geocoder60;
var marker61;
var geocoder61;
var marker62;
var geocoder62;
var marker63;
var geocoder63;
var marker64;
var geocoder64;
var marker65;
var geocoder65;
var marker66;
var geocoder66;
var marker67;
var geocoder67;
var marker68;
var geocoder68;
var marker69;
var geocoder69;
var marker70;
var geocoder70;
var marker71;
var geocoder71;
var marker72;
var geocoder72;
var marker73;
var geocoder73;
var marker74;
var geocoder74;
var marker75;
var geocoder75;
var marker76;
var geocoder76;
var marker77;
var geocoder77;
var marker78;
var geocoder78;
var marker79;
var geocoder79;
var marker80;
var geocoder80;
var marker91;
var geocoder91;
var marker92;
var geocoder92;
var marker93;
var geocoder93;
var marker94;
var geocoder94;
var marker95;
var geocoder95;
var marker96;
var geocoder96;
var marker97;
var geocoder97;
var marker98;
var geocoder98;
var marker99;
var geocoder99;
var icons=["#FF0000","#FFFF00","#000080","#008000","#800080"]; //色の指定

function initMap() {
    geocoder = new google.maps.Geocoder();
    geocoder.geocode({'address': readdata[0][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            map = new google.maps.Map(document.getElementById('map'), { // #sampleに地図を埋め込む
                center: results[0].geometry.location,
                zoom: 19 // 地図のズームを指定
            });
            marker=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[0][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[0][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder1 = new google.maps.Geocoder();
    geocoder1.geocode({'address': readdata[1][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker1=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[1][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[1][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder2 = new google.maps.Geocoder();
    geocoder2.geocode({'address': readdata[2][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker2=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[2][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[2][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder3 = new google.maps.Geocoder();
    geocoder3.geocode({'address': readdata[3][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker3=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[3][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[3][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status); 
        }
    });
    geocoder4 = new google.maps.Geocoder();
    geocoder4.geocode({'address': readdata[4][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker4=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[4][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[4][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap2() {
    geocoder5 = new google.maps.Geocoder();
    geocoder5.geocode({'address': readdata[5][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker5=new google.maps.Marker({
                position: results[0].geometry.location,
                icon: {
                    fillColor: icons[Number(readdata[5][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[5][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
            marker5.setMap(map);
        }else{
            alert(status);
        }
    });
    geocoder6 = new google.maps.Geocoder();
    geocoder6.geocode({'address': readdata[6][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker6=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[6][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[6][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder7 = new google.maps.Geocoder();
    geocoder7.geocode({'address': readdata[7][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker7=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[7][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[7][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder8 = new google.maps.Geocoder();
    geocoder8.geocode({'address': readdata[8][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker8=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[8][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[8][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder9 = new google.maps.Geocoder();
    geocoder9.geocode({'address': readdata[9][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker9=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[9][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[9][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap3() {
    geocoder10 = new google.maps.Geocoder();
    geocoder10.geocode({'address': readdata[10][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker10=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[10][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[10][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder11 = new google.maps.Geocoder();
    geocoder11.geocode({'address': readdata[11][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker11=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[11][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[11][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder12 = new google.maps.Geocoder();
    geocoder12.geocode({'address': readdata[12][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker12=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[12][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[12][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder13 = new google.maps.Geocoder();
    geocoder13.geocode({'address': readdata[13][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker13=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[13][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[13][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder14 = new google.maps.Geocoder();
    geocoder14.geocode({'address': readdata[14][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker14=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[14][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[14][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap4() {
    geocoder15 = new google.maps.Geocoder();
    geocoder15.geocode({'address': readdata[15][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker15=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[15][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[15][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder16 = new google.maps.Geocoder();
    geocoder16.geocode({'address': readdata[16][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker16=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[16][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[16][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder17 = new google.maps.Geocoder();
    geocoder17.geocode({'address': readdata[17][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker17=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[17][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[17][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder18 = new google.maps.Geocoder();
    geocoder18.geocode({'address': readdata[18][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker18=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[18][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[18][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder19 = new google.maps.Geocoder();
    geocoder19.geocode({'address': readdata[19][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker19=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[19][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[19][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap5() {
    geocoder20 = new google.maps.Geocoder();
    geocoder20.geocode({'address': readdata[20][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker15=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[20][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[20][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder21 = new google.maps.Geocoder();
    geocoder21.geocode({'address': readdata[21][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker21=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[21][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[21][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder22 = new google.maps.Geocoder();
    geocoder22.geocode({'address': readdata[22][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker22=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[22][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[22][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder23 = new google.maps.Geocoder();
    geocoder23.geocode({'address': readdata[23][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker23=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[23][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[23][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder24 = new google.maps.Geocoder();
    geocoder24.geocode({'address': readdata[24][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker24=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[24][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[24][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap6() {
    geocoder25 = new google.maps.Geocoder();
    geocoder25.geocode({'address': readdata[25][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker25=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[25][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[25][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder26 = new google.maps.Geocoder();
    geocoder26.geocode({'address': readdata[26][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker26=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[26][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[26][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder27 = new google.maps.Geocoder();
    geocoder27.geocode({'address': readdata[27][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker27=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[27][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[27][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder28 = new google.maps.Geocoder();
    geocoder28.geocode({'address': readdata[28][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker28=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[28][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[28][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder29 = new google.maps.Geocoder();
    geocoder29.geocode({'address': readdata[29][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker29=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[29][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[29][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap7() {
    geocoder30 = new google.maps.Geocoder();
    geocoder30.geocode({'address': readdata[30][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker15=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[30][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[30][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder31 = new google.maps.Geocoder();
    geocoder31.geocode({'address': readdata[31][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker31=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[31][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[31][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder32 = new google.maps.Geocoder();
    geocoder32.geocode({'address': readdata[32][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker32=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[32][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[32][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder33 = new google.maps.Geocoder();
    geocoder33.geocode({'address': readdata[33][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker33=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[33][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[33][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder34 = new google.maps.Geocoder();
    geocoder34.geocode({'address': readdata[34][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker34=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[34][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[34][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap8() {
    geocoder35 = new google.maps.Geocoder();
    geocoder35.geocode({'address': readdata[35][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker35=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[35][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[35][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder36 = new google.maps.Geocoder();
    geocoder36.geocode({'address': readdata[36][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker36=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[36][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[36][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder37 = new google.maps.Geocoder();
    geocoder37.geocode({'address': readdata[37][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker37=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[37][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[37][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder38 = new google.maps.Geocoder();
    geocoder38.geocode({'address': readdata[38][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker38=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[38][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[38][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder39 = new google.maps.Geocoder();
    geocoder39.geocode({'address': readdata[39][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker39=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[39][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[39][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap9() {
    geocoder40 = new google.maps.Geocoder();
    geocoder40.geocode({'address': readdata[40][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker40=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[40][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[40][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder41 = new google.maps.Geocoder();
    geocoder41.geocode({'address': readdata[41][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker41=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[41][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[41][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder42 = new google.maps.Geocoder();
    geocoder42.geocode({'address': readdata[42][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker42=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[42][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[42][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder43 = new google.maps.Geocoder();
    geocoder43.geocode({'address': readdata[43][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker43=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[43][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[43][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder44 = new google.maps.Geocoder();
    geocoder44.geocode({'address': readdata[44][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker44=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[44][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[44][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap10() {
    geocoder45 = new google.maps.Geocoder();
    geocoder45.geocode({'address': readdata[45][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker45=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[45][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[45][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder46 = new google.maps.Geocoder();
    geocoder46.geocode({'address': readdata[46][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker46=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[46][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[46][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder47 = new google.maps.Geocoder();
    geocoder47.geocode({'address': readdata[47][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker47=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[47][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[47][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder48 = new google.maps.Geocoder();
    geocoder48.geocode({'address': readdata[48][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker48=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[48][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[48][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder49 = new google.maps.Geocoder();
    geocoder49.geocode({'address': readdata[49][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker49=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[49][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[49][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap11() {
    geocoder50 = new google.maps.Geocoder();
    geocoder50.geocode({'address': readdata[50][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker50=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[50][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[50][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder51 = new google.maps.Geocoder();
    geocoder51.geocode({'address': readdata[51][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker51=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[51][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[51][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder52 = new google.maps.Geocoder();
    geocoder52.geocode({'address': readdata[52][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker52=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[52][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[52][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder53 = new google.maps.Geocoder();
    geocoder53.geocode({'address': readdata[53][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker53=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[53][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[53][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder54 = new google.maps.Geocoder();
    geocoder54.geocode({'address': readdata[54][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker54=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[54][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[54][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap12() {
    geocoder55 = new google.maps.Geocoder();
    geocoder55.geocode({'address': readdata[55][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker55=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[55][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[55][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder56 = new google.maps.Geocoder();
    geocoder56.geocode({'address': readdata[56][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker56=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[56][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[56][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder57 = new google.maps.Geocoder();
    geocoder57.geocode({'address': readdata[57][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker57=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[57][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[57][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder58 = new google.maps.Geocoder();
    geocoder58.geocode({'address': readdata[58][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker58=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[58][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[58][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder59 = new google.maps.Geocoder();
    geocoder59.geocode({'address': readdata[59][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker59=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[59][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[59][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap13() {
    geocoder60 = new google.maps.Geocoder();
    geocoder60.geocode({'address': readdata[60][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker15=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[60][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[60][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder61 = new google.maps.Geocoder();
    geocoder61.geocode({'address': readdata[61][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker61=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[61][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[61][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder62 = new google.maps.Geocoder();
    geocoder62.geocode({'address': readdata[62][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker62=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[62][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[62][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder63 = new google.maps.Geocoder();
    geocoder63.geocode({'address': readdata[63][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker63=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[63][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[63][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder64 = new google.maps.Geocoder();
    geocoder64.geocode({'address': readdata[64][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker64=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[64][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[64][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap14() {
    geocoder65 = new google.maps.Geocoder();
    geocoder65.geocode({'address': readdata[65][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker65=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[65][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[65][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder66 = new google.maps.Geocoder();
    geocoder66.geocode({'address': readdata[66][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker66=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[66][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[66][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder67 = new google.maps.Geocoder();
    geocoder67.geocode({'address': readdata[67][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker67=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[67][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[67][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder68 = new google.maps.Geocoder();
    geocoder68.geocode({'address': readdata[68][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker68=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[68][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[68][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder69 = new google.maps.Geocoder();
    geocoder69.geocode({'address': readdata[69][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker69=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[69][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[69][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap15() {
    geocoder70 = new google.maps.Geocoder();
    geocoder70.geocode({'address': readdata[70][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker70=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[70][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[70][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder71 = new google.maps.Geocoder();
    geocoder71.geocode({'address': readdata[71][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker71=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[71][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[71][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder72 = new google.maps.Geocoder();
    geocoder72.geocode({'address': readdata[72][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker72=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[72][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[72][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder73 = new google.maps.Geocoder();
    geocoder73.geocode({'address': readdata[73][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker73=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[73][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[73][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder74 = new google.maps.Geocoder();
    geocoder74.geocode({'address': readdata[74][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker74=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[74][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[74][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap16() {
    geocoder75 = new google.maps.Geocoder();
    geocoder75.geocode({'address': readdata[75][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker75=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[75][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[75][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder76 = new google.maps.Geocoder();
    geocoder76.geocode({'address': readdata[76][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker76=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[76][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[76][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder77 = new google.maps.Geocoder();
    geocoder77.geocode({'address': readdata[77][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker77=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[77][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[77][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder78 = new google.maps.Geocoder();
    geocoder78.geocode({'address': readdata[78][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker78=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[78][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[78][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder79 = new google.maps.Geocoder();
    geocoder79.geocode({'address': readdata[79][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker79=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[79][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[69][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap17() {
    geocoder80 = new google.maps.Geocoder();
    geocoder80.geocode({'address': readdata[80][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker80=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[80][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[80][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder81 = new google.maps.Geocoder();
    geocoder81.geocode({'address': readdata[81][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker81=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[81][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[81][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder82 = new google.maps.Geocoder();
    geocoder82.geocode({'address': readdata[82][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker82=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[82][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[82][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder83 = new google.maps.Geocoder();
    geocoder83.geocode({'address': readdata[83][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker83=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[83][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[83][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder84 = new google.maps.Geocoder();
    geocoder84.geocode({'address': readdata[84][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker84=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[84][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[84][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap18() {
    geocoder85 = new google.maps.Geocoder();
    geocoder85.geocode({'address': readdata[85][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker85=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[85][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[85][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder86 = new google.maps.Geocoder();
    geocoder86.geocode({'address': readdata[86][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker86=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[86][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[86][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder87 = new google.maps.Geocoder();
    geocoder87.geocode({'address': readdata[87][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker87=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[87][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[87][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder88 = new google.maps.Geocoder();
    geocoder88.geocode({'address': readdata[88][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker88=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[88][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[88][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder89 = new google.maps.Geocoder();
    geocoder89.geocode({'address': readdata[89][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker79=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[89][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[89][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}
function initMap19() {
    geocoder90 = new google.maps.Geocoder();
    geocoder90.geocode({'address': readdata[90][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker90=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[90][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[90][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder91 = new google.maps.Geocoder();
    geocoder91.geocode({'address': readdata[91][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker91=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[91][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[91][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder92 = new google.maps.Geocoder();
    geocoder92.geocode({'address': readdata[92][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker92=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[92][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[92][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder93 = new google.maps.Geocoder();
    geocoder93.geocode({'address': readdata[93][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker93=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[93][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[93][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
    geocoder94 = new google.maps.Geocoder();
    geocoder94.geocode({'address': readdata[94][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            marker94=new google.maps.Marker({
                position: results[0].geometry.location,
                map: map,
                icon: {
                    fillColor: icons[Number(readdata[94][1])],//塗りつぶし色
                    fillOpacity: 0.8, //透過率
                    path: google.maps.SymbolPath.CIRCLE, //形
                    scale:8,                           //円のサイズ
		            strokeColor: icons[Number(readdata[94][1])],              //枠の色
	                strokeWeight: 1.0  
                }
            });
        }else{
            alert(status);
        }
    });
}

    // for(var j=0;j<2;j++){
    //     marker[j]=new google.maps.Marker({
    //         position: location[j],
    //         map: map,
    //         icon: {
    //             fillColor: icons[Number(readdata[j][1])],//塗りつぶし色
    //             fillOpacity: 0.8, //透過率
    //             path: google.maps.SymbolPath.CIRCLE, //形
    //             scale:8,                           //円のサイズ
		  //      strokeColor: icons[Number(readdata[j][1])],              //枠の色
	   //         strokeWeight: 1.0  
    //         }
    //     });
    // }