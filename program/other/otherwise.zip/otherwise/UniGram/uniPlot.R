token=read.table("/Users/kazuki/Documents/Study/data/uniGram/goi.txt",heade=T)
bun0=read.table("/Users/kazuki/Documents/Study/data/uniGram/wiki/00.txt",header=T)
goi=token$単語
goi0=bun0$単語
frequency=integer(length(goi))
fre0=bun0$頻度
N=sum(fre0)
fre0=fre0/N
names(frequency)=goi
names(fre0)=goi0
for(i in goi0){
  frequency[i] = fre0[i] 
}
Freq=sort(frequency,decreasing = T)
par(family = "HiraKakuProN-W3")
barplot(Freq,main="単語分布",las=2,xlab="",ylim=c(0,0.035))

