# -*- coding: utf-8 -*-
import MeCab
import sys
import codecs
import string
import math
import os
import glob
import copy

def Baseon(Ch):
	return Ch.feature.split(",") #Mecab形式ノードの分割

text={};text_l={};fname=[]#行ごとのてきすと,行数,ファイル名
D={};#全体の辞書
W={}#各ファイルの辞書
stWd=("する","ない","いる","ある","くださる","れる") #ストップワード
try:
	#作業場所に移動
	os.chdir("../data/data")
	#MeCabの設定
	t=MeCab.Tagger("-Ochasen -d /usr/local/lib/mecab/dic/mecab-ipadic-neolog ".join(sys.argv))
	for All_f in glob.glob('*.txt'):
		f=codecs.open(All_f,'r',"utf-8") #ファイルオープン utf-8で
		# text[All_f]=f.read().split("\n") #改行ごとに区切る
		text=f.read().split("\n")
		f.close()
		fn=All_f
		fname.append(fn) #利用したファイルのストック
		#text_l[fn]=len(text[fn]) #ファイルごとの行数:辞書型
		fD={} #ファイルごとの辞書
		for ch in text: #行ごとの処理
			m=t.parseToNode(ch) #MeCab形式のノード変換
			while m: #分割した単語ごとでの処理
				d=Baseon(m)
				if (d[0]=="名詞")and(d[1]!="接尾")and(d[6]!="*")and(d[6] not in stWd):
					#辞書への登録
					if d[6] in fD:
						fD[d[6]]+=1
					else:
						fD[d[6]]=1
				m=m.next
		#各語彙リストの作成
		# wf=open("../topic/sports/"+All_f,'w',encoding='utf-8')
		# wf.write("単語 頻度\n")
		# for k,v in fD.items():
		# 	wf.write("{0} {1}\n".format(k,v))
		# wf.close()
		D.update(fD) #辞書の統合
		W[fn]=copy.copy(fD)
	#辞書の更新
	fname.sort()
	for fn in fname:
		d0={k:0 for k in D.keys() if k not in W[fn].keys()}
		W[fn].update(d0)
	#使用するファイル区間の語彙データ
	wf=open("../total.csv",'w',encoding='utf-8')
	wf.write("単語,全体,{}\n".format(",".join(fname)))
	for k,v in D.items():
		wf.write("{},{}".format(k,v))
		for fn in fname:
			print(fn)
			wf.write(",{}".format(W[fn][k]))
		wf.write("\n")
	wf.close()
	print("EOS");
except RuntimeError as e:
	print("RuntimeError:",e);
