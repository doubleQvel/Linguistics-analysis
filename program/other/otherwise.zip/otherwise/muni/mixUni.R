mix=read.csv("/Users/kazuki/Documents/Study/4-11/data/test.csv")
attach(mix)
par(family="HiraKakuProN-W3")
