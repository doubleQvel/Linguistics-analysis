# -*- coding: utf-8 -*-
#ファイルリストからの全リストの作成
import sys
import codecs
import string
import math
import os
import glob
import copy
#ファイル読み込み
argvs=sys.argv
argc=len(sys.argv)
if argc!=2:
    print('Usage: # python {} dirname'.format(argvs[0]))
    quit()
dirname=argvs[1]
#ファイルごとの辞書作成
os.chdir(dirname)
rf=codecs.open(dirname+"/filelist.txt",'r',"utf-8")#ファイルリストの読み込み
filelist=rf.read().split("\n")
rf.close()
#各ファイル辞書
D={}
fd=[{} for i in range(len(filelist))]
for i,file in enumerate(filelist):
    rf=codecs.open("./original/"+file,'r',"utf-8")
    text=rf.read().split()
    rf.close()
    for word in text:
        if(word in fd[i]):
            fd[i][word]+=1
        else:
            fd[i][word]=1
    D.update(fd[i])
#各ファイルの最終調整
for i,file in enumerate(filelist):
    d0={word:0 for word in D.keys() if word not in fd[i].keys()}
    fd[i].update(d0)
#ファイル書き込み
wf=open("./total.csv","w",encoding='utf-8')
wf.write("単語,{}\n".format(",".join(filelist)))
for k,v in D.items():
    wf.write("{}".format(k,v))
    for i in range(len(filelist)):
        wf.write(",{}".format(fd[i][k]))
    wf.write("\n")
wf.close()
print("EOS")