#ライブラリを使ったトピックモデル 
par(family="HiraKakuProN-W3")
#ライブラリの使用
library(topicmodels)
library(tm)
library(slam)
library(lda)
#ファイル読み込み(すでに加工済み)
setwd('/Users/kazuki/Documents/Study/data/4-25/')
learndata=read.csv("total.csv")
#データからの各要素の加工
#topicmodelsによるLDA
#単語分布,トピック分布を調べる

library(topicmodels)
library(lda)
library(RMeCab)
#文章を読み込む
wd <- "/iwata/mecab/"
kokoroe <- list.files(wd, "txt")

lex <- c("名詞", "動詞", "形容詞")
doc0 <- rep(0, length(kokoroe))
for(i in seq(doc0)){
  tmp <- read.delim(paste(wd, kokoroe[i], sep=""), header=FALSE)
  word <- unlist(mapply(function(x) grep(x, as.character(tmp[,4])), lex))
  doc0[[i]] <- paste(as.character(tmp[word, 3]), collapse=" ")
}

lex1 <- lexicalize(doc0) 
dtm1 <- ldaformat2dtm(lex1$documents, lex1$vocab) #なんちゃらmatrixに変換
ctm1 <- CTM(dtm1, 10) #CTM?
#重要度の低い単語の削除する関数の作成
TFIDF <- function(corpus, progress=FALSE){ # lexicalize した corpus を使用
  res <- matrix(0, nr=length(corpus$vocab), nc=4)
  dimnames(res) <- list(corpus$vocab, c("documents", "count", "freq", "score"))
  res[, "documents"] <- length(corpus$documents)
  wordset <- mapply(function(x) x[1,], corpus$documents) # documents中の単語リスト
  allfreq <- matrix(unlist(corpus$documents), nr=2)
  wordfreq <- tapply(allfreq[2,], allfreq[1,], sum) # すべての単語の、全documents中の出現頻度
  for(v in seq(corpus$vocab)){ # vocab と i は 1 ずれているので注意
    count_docs <- sum(sapply(lapply(wordset, "==", v-1), any)) # その単語が出現する文章の数
    res[v, "freq"] <- count_docs
    if(progress){ # Linux用。プログレスバーを付ける
      pb <- txtProgressBar(min=1, max=length(corpus$vocab), style=3)
      setTxtProgressBar(pb, v)
    }
  }
  res[, "count"] <- wordfreq
  res[, "score"] <- log(res[, "count"]) * log(res[, "documents"]/res[, "freq"])
  return(as.data.frame(res))
}

s0 <- TFIDF(lex1, TRUE) #TFIDFの実行
term1 <- rownames(s0)[s0$score > 0]
lex2 <- list(documents=lexicalize(doc0, vocab=term1), vocab=term1)
dtm2 <- ldaformat2dtm(lex2$documents, lex2$vocab)
ctm2 <- CTM(dtm2, 10)

g0 <- ctm2@gamma
t0 <- c(as.matrix(read.delim("clipboard", header=FALSE))) # タイトル一覧
rownames(g0) <- paste(paste(paste("Topic", topics(ctm2), sep=""), seq(nrow(g0)), sep=" #"), t0)
h0 <- hclust(dist(g0), method="ward")
plot(h0, xlab="心得")