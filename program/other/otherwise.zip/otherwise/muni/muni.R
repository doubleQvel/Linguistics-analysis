token=read.table("/Users/kazuki/Documents/Study/data/yahoo/goi.txt",heade=T)
economic=read.table("/Users/kazuki/Documents/Study/data/yahoo/topic/economic/e0.txt",header=T)
IT=read.table("/Users/kazuki/Documents/Study/data/yahoo/topic/IT/i0.txt",header=T)
sports=read.table("/Users/kazuki/Documents/Study/data/yahoo/total/sports.txt",header = T)
#リストの作成(初期値thetaおよびphiの設定)
#トピックリストthetaの作成
theta=c(1,1,3)
Topics=c("経済","IT","スポーツ")
names(theta)=Topics
Nk=sum(theta)
theta=theta/Nk
#語彙リストの作成
goi=token$単語 #語彙のリスト
#各トピックの単語分布 行列
eF=integer(length(goi))
iF=integer(length(goi))
sF=integer(length(goi))
names(eF)=goi
names(iF)=goi
names(sF)=goi
eT=economic$単語
iT=IT$単語
sT=sports$単語
ef0=economic$頻度
if0=IT$頻度
sf0=sports$頻度
names(ef0)=eT
names(if0)=iT
names(sf0)=sT
Ne=sum(ef0)
ef0=ef0/Ne
Ni=sum(if0)
if0=if0/Ni
Ns=sum(sf0)
sf0=sf0/Ns
for(i in eT){ eF[i]=ef0[i] }
for(i in iT){ iF[i]=if0[i] }
for(i in sT){ sF[i]=sf0[i] }
Phi=matrix(c(eF,iF,sF),nrow=length(goi),ncol=3)
rownames(Phi)=goi
colnames(Phi)=Topics
i=1
while (i>0) {
  #次パラメータの初期化
  nTheta=c(0,0,0)
  nPhi=matrix(integer(length(goi)*3),nrows=length(goi),ncol=3)
  #Eステップ
  #Mステップ  
}
