"+" <- function(e1, e2) {
  if (is.character(c(e1, e2))) {
    paste(e1, e2, sep = "")
  } else {
    base::"+"(e1, e2)
  }
}
#トピックモデルに関する推定方法
par(family="HiraKakuProN-W3")
#ファイル読み込み(すでに加工済み)
setwd('/Users/kazuki/Documents/Study/data/4-25/')
learndata=read.csv("total.csv")
#データからの各要素の加工
D=length(learndata[1,])-1 #文書数
V=length(learndata[,1]) #語彙数
Nv=apply(learndata[,2:length(learndata[1,])],1,sum)#語彙vの出現回数
names(Nv)=learndata[,1]
Nd=apply(learndata[,2:length(learndata[1,])],2,sum) #文書dの単語延べ数
Ndv=learndata[,2:length(learndata)]
N=sum(Nd)#文書集合全体での単語延べ数
K=5 #トピック数

#ベイズ推定法
alpha=0
#qの計算
#alpha,betaの更新
