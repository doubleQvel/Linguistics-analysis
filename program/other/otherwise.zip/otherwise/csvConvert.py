# -*- coding: utf-8 -*-
import MeCab
import sys
import codecs
import string
import math
import os
import glob
import copy

def Baseon(Ch):
	return Ch.feature.split(",") #Mecab形式ノードの分割
def tokenParse(text):
	token=text.split(" ")
	return token[0]
#CSVへの変換およびファイルの結合
text={};text_l={};fname=[]#行ごとのてきすと,行数,ファイル名
D={};#全体の辞書
fn=3#使用するファイル数
fname=["../data/yahoo/topic/IT/i0.txt","../data/yahoo/topic/IT/i1.txt","../data/yahoo/topic/economic/e0.txt"]
try:
	#学習済み語彙リスト
	rf=open("../data/yahoo/goi.txt",'r',encoding='utf-8')
	text=rf.read().split("\n")
	rf.close()
	token=list(map(tokenParse,text))
	goi={k:["0"]*len(fname) for k in token}
	#テストデータ
	for i,file in enumerate(fname):
		rf=open(fname[i],'r',encoding='utf-8')
		text=rf.read().split("\n")
		text=list(map(lambda n:n.split(" "),text))
		for fq in text:
			print(fq)
			if(fq[0]!=""):
				goi[fq[0]][i]=fq[1]
	print(goi)
	wf=open("../4-11/data/test.csv",'w',encoding='utf-8')
	wf.write("Token,i0,i1,e0\n")
	for k,v in goi.items():
		ss=",".join(v)
		print(ss)
		wf.write("{0},{1}\n".format(k,ss))
	wf.close()
	print("EOS");
except RuntimeError as e:
	print("RuntimeError:",e);
