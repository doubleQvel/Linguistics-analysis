"+" <- function(e1, e2) {
  if (is.character(c(e1, e2))) {
    paste(e1, e2, sep = "")
  } else {
    base::"+"(e1, e2)
  }
}
setwd('/Users/kazuki/Documents/Study/data/4-18/so/')
library(lda)
par(family="HiraKakuProN-W3")
file_list=read.table("filelist.txt",header=F,stringsAsFactors=F)
files=file_list[,1]
file_num=length(files)
for(i in 1:file_num){
  if(i==1){
    V=scan(files[i], what = character(), sep = "\n", blank.lines.skip = F)
  }else{
    v=scan(files[i], what = character(), sep = "\n", blank.lines.skip = F)
    V=c(V,v)
  }
}
test=lexicalize(V,lower = TRUE)
K=4
result <- lda.collapsed.gibbs.sampler(test$documents, K, test$vocab, 25, 0.1, 0.1, compute.log.likelihood=TRUE)
top.words <- top.topic.words(result$topics, 3, by.score=TRUE)
N=file_num
topic.proportions <- t(result$document_sums) / colSums(result$document_sums)
topic.proportions <- topic.proportions[1:N, ]
topic.proportions[is.na(topic.proportions)] <-  1 / K
colnames(topic.proportions) <- apply(top.words, 2, paste, collapse=" ")
par(mar=c(5, 5, 2, 14))
par(xpd=T)
barplot(t(topic.proportions),las=1, xlab="proportion",col=gray(seq(0,1,1/K)))
#barplot(t(topic.proportions),las=1, xlab="proportion")
legend(par()$usr[2],par()$usr[4],legend=colnames(topic.proportions),pch=22,pt.bg=gray(seq(0,1,1/K)))
#各トピックでの単語分布を見たい
words=top.topic.words(result$topics, 1900, by.score=TRUE)
#トピック分布を見たい
