# -*- coding: utf-8 -*-
#ストップワードおよび正規表現によるノイズの削除
import sys
import codecs
import string
import math
import os
import glob
import copy
import re

argvs=sys.argv
argc=len(sys.argv)
if argc!=2:
    print('Usage: # python {} dirname'.format(argvs[0]))
    quit()
dirname=argvs[1]
text={};text_l={};fname=[]#行ごとのてきすと,行数,ファイル名
D={};#全体の辞書
W={}#各ファイルの辞書
#ストップワードの導入
fp=codecs.open("/Users/kazuki/Documents/Study/program/stopwords.txt",'r',"utf-8")
stopwords=fp.read().split("\n")
fp.close()
fp=codecs.open("/Users/kazuki/Documents/Study/program/customStopWords.txt",'r',"utf-8")
stopwords=stopwords+fp.read().split("\n")
fp.close()
#正規表現入力(数値に対してのみ)数値が入っているものすべて
pattern=r'([０-９])'
#ファイル読み込み
os.chdir(dirname+"/original")
for All_f in glob.glob('*.txt'):
    rf=codecs.open(All_f,'r',"utf-8") #ファイルオープン utf-8で
    text=rf.read().split()
    rf.close()
    fn,ext=os.path.splitext(All_f)
    fname.append(fn) #利用したファイルのストック
    # for word in text:
    #     # print(word)
    #     suji=re.match(pattern,word)
    #     if suji:
    #         print(suji.group())
    #ストップワードおよび検出
    text=[word for word in text if word not in stopwords]
    text=[word for word in text if not re.match(pattern,word)]
    #ファイル出力
    wf=open(dirname+"/original/"+fn+".txt","w",encoding='utf-8')
    wf.write("{}".format(" ".join(text)))
    wf.close()