// CSVファイルを読み込む関数getCSV()の定義
var idokeido=[];
var readdata=[];
function getCSV(){
    var fname="./gram3/VD.csv";
    // var fname= document.forms.Sample1_form.textbox.value;
    var req = new XMLHttpRequest(); // HTTPでファイルを読み込むためのXMLHttpRrequestオブジェクトを生成
    req.open("get",fname, true); // アクセスするファイルを指定
    req.send(null); // HTTPリクエストの発行allK5.csv
    // レスポンスが返ってきたらconvertCSVtoArray()を呼ぶ	
    req.onload = function(){
	convertCSVtoArray(req.responseText); // 渡されるのは読み込んだCSVデータ
    }

    var reqI=new XMLHttpRequest();
    reqI.open("get","./idokeido.csv", true); // アクセスするファイルを指定
    reqI.send(null); // HTTPリクエストの発行allK5.csv
    reqI.onload = function(){
	convertCSVtoIdoKeido(reqI.responseText); // 渡されるのは読み込んだCSVデータ
    }
}
// 読み込んだCSVデータを二次元配列に変換する関数convertCSVtoArray()の定義
function convertCSVtoArray(str){ // 読み込んだCSVデータが文字列として渡される
    // var result = []; // 最終的な二次元配列を入れるための配列
    var tmp = str.split("\n"); // 改行を区切り文字として行を要素とした配列を生成
 
    // 各行ごとにカンマで区切った文字列を要素とした二次元配列を生成
    // for(var i=1;i<tmp.length;++i){
    //     readdata[i-1] = tmp[i].split(',');
    // }
        for(var i=0;i<tmp.length;++i){
        readdata[i] = tmp[i].split(',');
    }
 
    // alert(readdata); // 300yen
}
function convertCSVtoIdoKeido(str){ // 読み込んだCSVデータが文字列として渡される
    var tmp = str.split("\n"); // 改行を区切り文字として行を要素とした配列を生成
    for(var i=0;i<tmp.length;++i){
        idokeido[i] = tmp[i].split(',');
    }
    // alert(idokeido[0]);
}
window.onload=getCSV();

var map;
var marker;
var geocoder;
var markers = new Array();
var geocoders = new Array();
// var icons=["#FF0000","#FFFF00","#000080","#008000","#800080",
//             "#000000","#ffdab9","#00ffff","#008080","#00ff00"    
//         ]; //色の指定
var icons=[
    "","#000000","#800000","#ff0000",
    "#800080","#ff8c00",
    "#ff00ff","#008000",
    "#808000","#000080",
    "#ff6633"
    ];
    
function f2(iorder){
    return new Promise((resolve,reject) => {
        var thisicon=icons[Number(readdata[iorder][1])];
        var markerLatLng = new google.maps.LatLng({lat: parseFloat(idokeido[iorder][0]), lng: parseFloat(idokeido[iorder][1]) });
        // alert(markerLatLng);
        markers[iorder]=new google.maps.Marker({
            position: markerLatLng,
            map: map,
            icon: {
                fillColor: thisicon,//塗りつぶし色
                fillOpacity: 0.8, //透過率
                path: google.maps.SymbolPath.CIRCLE, //形
                scale:4,                           //円のサイズ
		        strokeColor: thisicon,              //枠の色
	            strokeWeight: 1.0  
            }
        });
        resolve("OK");
    })
}


function f1(iorder){
    return new Promise((resolve,reject) => {
        var thisicon=icons[Number(readdata[iorder][1])];
        geocoders[iorder] = new google.maps.Geocoder();
        geocoder.geocode({'address': readdata[iorder][0]},function(results,status){
            if (status === google.maps.GeocoderStatus.OK){
                markers[iorder]=new google.maps.Marker({
                    position: results[0].geometry.location,
                    map: map,
                    icon: {
                        fillColor: thisicon,//塗りつぶし色
                        fillOpacity: 0.8, //透過率
                        path: google.maps.SymbolPath.CIRCLE, //形
                        scale:4,                           //円のサイズ
		                strokeColor: thisicon,              //枠の色
	                    strokeWeight: 1.0  
                    }
                });
                alert(readdata[iorder][0]);
                alert(results[0].geometry.location);
            }
            else{
                alert(status);
            }
        });
        resolve("OK");
    })
}

function initMap() {
    geocoder = new google.maps.Geocoder();
    geocoder.geocode({'address': readdata[0][0]},function(results,status){
        if (status === google.maps.GeocoderStatus.OK){
            map = new google.maps.Map(document.getElementById('map'), { // #sampleに地図を埋め込む
                center: results[0].geometry.location,
                zoom: 19, // 地図のズームを指定
                mapTypeId: google.maps.MapTypeId.TERRAIN
            });
        }else{
            alert(status);
        }
    });
}
function settingMarker(j){
    var tmp=10;
    if(j==90){
        tmp=6;
    }
    for(var i=j;i<j+tmp;i++){
        f2(i);
    }
}

function writingmarker(){
    var markerLatLng = new google.maps.LatLng({lat: parseFloat(idokeido[0][0]), lng: parseFloat(idokeido[0][1]) });
    map = new google.maps.Map(document.getElementById('map'), { // #sampleに地図を埋め込む
        center: markerLatLng,
        zoom: 10, // 地図のズームを指定
        mapTypeId: google.maps.MapTypeId.TERRAIN
    });
    var tmp=95;
    for(var i=0;i<tmp;i++){
        f2(i);
        // alert("OK");
    }
    // f2(5);
}