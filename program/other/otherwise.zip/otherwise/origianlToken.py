# -*- coding: utf-8 -*-
import MeCab
import sys
import codecs
import string
import math
import os
import glob
import copy

def Baseon(Ch):
    return Ch.feature.split(",") #Mecab形式ノードの分割

text={};text_l={};fname=[]#行ごとのてきすと,行数,ファイル名
D={};#全体の辞書
W={}#各ファイルの辞書
stWd=("する","ない","いる","ある","くださる","れる") #ストップワード
try:
    #作業場所に移動
    os.chdir("../data/4-18/swiming")
    #MeCabの設定
    t=MeCab.Tagger("-Ochasen -d /usr/local/lib/mecab/dic/mecab-ipadic-neolog ".join(sys.argv))
    for All_f in glob.glob('*.txt'):
        f=codecs.open(All_f,'r',"utf-8") #ファイルオープン utf-8で
        # text[All_f]=f.read().split("\n") #改行ごとに区切る
        text=f.read().split("\n")
        f.close()
        fn,ext=os.path.splitext(All_f)
        fname.append(fn) #利用したファイルのストック
        #text_l[fn]=len(text[fn]) #ファイルごとの行数:辞書型
        fD={} #ファイルごとの辞書
        word=[]
        for ch in text: #行ごとの処理
            m=t.parseToNode(ch) #MeCab形式のノード変換
            while m: #分割した単語ごとでの処理
                d=Baseon(m)
                if (d[0]=="名詞")and(d[1]!="接尾")and(d[6]!="*")and(d[6] not in stWd):
                    #辞書への登録
                    word.append(d[6])
                m=m.next
        wf=open("../so/"+fn+".txt",'w',encoding='utf-8')
        wf.write("{}".format(" ".join(word)))
        wf.close()
    fname.sort()
    wf=open("../so/filelist.txt",'w',encoding='utf-8')
    for fn in fname:
        wf.write("{}\n".format(fn+".txt"))
    wf.close()
    print("EOS")
except RuntimeError as e:
	print("RuntimeError:",e);