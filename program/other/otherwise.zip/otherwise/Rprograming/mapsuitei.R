#MAP推定に関する話
par(family="HiraKakuProN-W3")
#ファイル読み込み(すでに加工済み)
setwd('/Users/kazuki/Documents/Study/data/4-25/')
learndata=read.csv("total.csv")
#データからの各要素の加工
D=length(learndata[1,])-1 #文書数
Nd=apply(learndata[,2:D],2, sum) #文書dの単語延べ数
V=length(learndata[,1]) #語彙数
N=sum(Nd)#文書集合全体での単語延べ数
Nv=apply(learndata[,2:D], 1, sum)#語彙vの出現回数
names(Nv)=learndata[,1]
#最尤推定法の場合
theta=Nv/N
#MAP推定法
MAP=(Nv+2-1)/(N+(2-1)*V)
#ベイズ推定
BEIZU=(Nv+2)/(N+2*V)
