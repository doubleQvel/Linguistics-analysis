# -*- coding: utf-8 -*-
import MeCab
import sys
import codecs
import string
import math
import os
import glob
import copy

text={};text_l={};fname=[]#行ごとのてきすと,行数,ファイル名
D={}
os.chdir("../data/yahoo/total")
for All_f in glob.glob('*.txt'):
    f=codecs.open(All_f,'r',"utf-8") #ファイルオープン utf-8で
    text[All_f]=f.read().split("\n") #改行ごとに区切る
    f.close
    fD={}
    for pl in text[All_f]:
        pl=pl.split(" ")
        if (pl[0]=="単語" and pl[1]=="頻度")or len(pl)==1:
            continue
        if pl[0] in fD:
            fD[pl[0]]+= pl[1]
        else:
            fD[pl[0]]= pl[1]
    D.update(fD) #辞書の統合
wf=open("../goi.txt",'w',encoding='utf-8')
wf.write("単語 頻度\n")
for k,v in D.items():
    wf.write("{0} {1}\n".format(k,v))
wf.close()
print("EOS");
